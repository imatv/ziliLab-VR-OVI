﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System;

public class fileCheck : MonoBehaviour {

	private String output = "hi";

	// Use this for initialization
	void Start () {
		string filePath = "C:/Users/PILE/Desktop/VRDATA/3001_A.txt";
		if (File.Exists(filePath)) {
			filePath += ".txt";
		}
		Debug.Log (filePath);
		System.IO.File.WriteAllText(filePath, output);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
